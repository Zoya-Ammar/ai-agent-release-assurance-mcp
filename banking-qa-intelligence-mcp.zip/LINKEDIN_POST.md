Six days ago, I shared that a Snowflake webinar on MCP had given me a plan.

Here is what I built: a Banking QA Intelligence MCP server.

The server lets an AI assistant analyze synthetic release, test, and defect data through
four purpose-built tools. It can identify failed critical tests, rank defect hotspots,
recommend a targeted regression suite, and return an explainable GO / CONDITIONAL GO /
NO-GO assessment.

The most important design decision was keeping the judgment grounded. The model does not
invent a risk score. The server returns the calculation, the evidence behind it, and the
specific blockers so a human can review the recommendation.

What worked:

- Typed Python functions made the MCP tool schemas straightforward.
- Structured tool outputs kept the AI response tied to test and defect evidence.
- Synthetic data let me model a financial-services workflow without using sensitive data.

What challenged me:

- A useful tool needs a narrow purpose and a description clear enough for an AI client to
  select it correctly.
- A technically valid score is not automatically a trustworthy one. The rules must be
  visible, testable, and owned by the right humans.
- Read-only access, least privilege, auditability, and human approval matter even in an MVP.

This first version uses SQLite so anyone can reproduce it locally. I also mapped the next
step to Snowflake's native MCP server capability.

Next, I want to add a Snowflake-backed repository adapter and an evaluation suite that
measures tool selection and factual grounding.

Repository: [ADD GITHUB LINK]

#ModelContextProtocol #MCP #Python #SoftwareTesting #QualityEngineering #AIEngineering
#Snowflake #FinTech #BuildInPublic

